import { ExperienceChunk } from './types.js';

// Simple in-memory vector store for M2
// Since most CVs have < 20 chunks, simple cosine similarity is enough
export class KnowledgeStore {
  private corpus: ExperienceChunk[] = [];

  async upsertCorpus(corpus: ExperienceChunk[]): Promise<void> {
    this.corpus = corpus;
  }

  private cosineSimilarity(vecA: number[], vecB: number[]): number {
    let dotProduct = 0;
    let normA = 0;
    let normB = 0;
    for (let i = 0; i < vecA.length; i++) {
      dotProduct += vecA[i] * vecB[i];
      normA += vecA[i] * vecA[i];
      normB += vecB[i] * vecB[i];
    }
    return dotProduct / (Math.sqrt(normA) * Math.sqrt(normB));
  }

  async retrieve(queryEmbedding: number[], k: number = 3): Promise<ExperienceChunk[]> {
    if (this.corpus.length === 0) return [];
    
    const scored = this.corpus.map(chunk => ({
      chunk,
      score: chunk.embedding ? this.cosineSimilarity(queryEmbedding, chunk.embedding) : 0
    }));

    return scored
      .sort((a, b) => b.score - a.score)
      .slice(0, k)
      .map(s => s.chunk);
  }

  getAll(): ExperienceChunk[] {
    return this.corpus;
  }
}
