import * as fs from 'fs';
import * as path from 'path';
import mammoth from 'mammoth';
import { createRequire } from 'module';
const require = createRequire(import.meta.url);
const pdf = require('pdf-parse');
import { OpenAI } from 'openai';
import { ExperienceChunk, PersonaProfile } from './types.js';
import { config } from './config.js';

const openai = new OpenAI({
  apiKey: config.LLM_KEY,
  baseURL: config.LLM_BASE_URL,
});

async function extractText(filePath: string): Promise<string> {
  const ext = path.extname(filePath).toLowerCase();
  if (ext === '.docx') {
    const result = await mammoth.extractRawText({ path: filePath });
    return result.value;
  } else if (ext === '.pdf') {
    const dataBuffer = fs.readFileSync(filePath);
    const data = await pdf(dataBuffer);
    return data.text;
  } else {
    return fs.readFileSync(filePath, 'utf-8');
  }
}

export async function analyzeProfile(input: {
  files: string[];
  persona?: Partial<PersonaProfile>;
}): Promise<{ corpus: ExperienceChunk[]; persona: PersonaProfile }> {
  let combinedText = '';
  for (const file of input.files) {
    combinedText += await extractText(file) + '\n';
  }
  console.log('Combined Text for Analysis:', combinedText);

  const prompt = `
You are an expert interview coach and information architect.
Decompose the candidate's CV / cover letter / self-intro into ATOMIC EXPERIENCE CHUNKS
optimized for real-time retrieval during a live interview.

For EACH distinct experience (project, role, publication, achievement) output one JSON object:
{
  "id": "exp_<slug>",
  "source": "<where in the CV>",
  "title": "<short Korean title>",
  "competencies": ["<3-5 competencies proven>"],
  "star": {"S":"...","T":"...","A":"...","R":"..."},   // reconstruct even if implicit
  "metrics": ["<concrete numbers, model names, venues, dates from the CV ONLY>"],
  "likely_followups": ["<2-4 tough follow-ups an interviewer would ask>"],
  "hidden_angles": ["<1-3 non-obvious strengths/framings>"],
  "embedding_text": "<dense keyword-rich KO+EN string in the candidate's domain terms>"
}

RULES:
- NEVER invent facts/numbers/claims unsupported by the source. If unknown, omit the field's item.
- Be exhaustive: extract EVERY distinct experience, including publications and side projects.
- star & metrics must be grounded in the text; competencies & hidden_angles may be inferred.
- Also derive a PersonaProfile from the CV (research-oriented? cross-cultural? entrepreneurial?).
- Output strict JSON: { "corpus": [ ...chunks ], "persona": {...} }. No prose.
- Make sure to extract all projects and experiences.
`;

  const response = await openai.chat.completions.create({
    model: config.LLM_MODEL,
    messages: [
      { role: 'system', content: prompt },
      { role: 'user', content: combinedText },
    ],
    max_tokens: 4000,
  });

  let content = response.choices && response.choices[0] ? response.choices[0].message.content : '';
  console.log('Raw LLM Response:', content);
  
  if (!content) {
    console.error('LLM returned empty content');
    return { corpus: [], persona: { provided: [], derived: [], calibration: '' } };
  }

  // More robust JSON extraction
  let jsonStr = content;
  const jsonMatch = content.match(/\{[\s\S]*\}/);
  if (jsonMatch) {
    jsonStr = jsonMatch[0];
  }
  
  let result;
  try {
    result = JSON.parse(jsonStr);
  } catch (e) {
    console.error('Failed to parse JSON:', e);
    console.log('Attempted to parse:', jsonStr);
    result = { corpus: [], persona: {} };
  }
  
  // Embeddings disabled for now due to endpoint unavailability
  /*
  if (result.corpus) {
    for (const chunk of result.corpus) {
      const embResp = await openai.embeddings.create({
        model: config.EMBEDDING_MODEL,
        input: chunk.embedding_text,
      });
      if (embResp.data && embResp.data[0]) {
        chunk.embedding = embResp.data[0].embedding;
      }
    }
  }
  */

  return {
    corpus: result.corpus || [],
    persona: result.persona || { provided: [], derived: [], calibration: '' },
  };
}
