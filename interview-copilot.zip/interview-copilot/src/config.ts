import * as dotenv from 'dotenv';
dotenv.config();

export const config = {
  STT_KEY: process.env.STT_KEY || '',
  LLM_KEY: process.env.OPENAI_API_KEY || '', 
  LLM_BASE_URL: process.env.OPENAI_API_BASE || 'https://api.openai.com/v1',
  MT_KEY: process.env.MT_KEY || '',
  EMBED_KEY: process.env.OPENAI_API_KEY || '',
  VECTOR_URL: process.env.VECTOR_URL || '',
  
  // Default settings
  STT_VENDOR: 'deepgram', // or 'assemblyai'
  LLM_MODEL: 'gpt-5-mini',
  EMBEDDING_MODEL: 'text-embedding-3-small',
  
  // Latency goals
  LATENCY_P50: 800,
  LATENCY_P95: 1500,
};
