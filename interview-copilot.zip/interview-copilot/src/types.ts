// 지식베이스 레코드 (M1이 생성, M2가 저장/검색, M7이 소비)
export interface ExperienceChunk {
  id: string;                 // "exp_signcv"
  source: string;             // CV 내 출처
  title: string;              // 짧은 한국어 제목
  competencies: string[];     // 증명 역량 3~5개 (추론 허용)
  star: { S: string; T: string; A: string; R: string }; // 사실 근거, 창작 금지
  metrics: string[];          // 수치·모델명·학회·날짜 (CV 근거)
  likely_followups: string[]; // 예상 꼬리질문 2~4개
  hidden_angles: string[];    // 비자명 강점 1~3개
  embedding_text: string;     // 검색용 키워드 밀집 문자열 (KO+EN)
  embedding?: number[];       // 벡터
}

export interface PersonaProfile {
  provided: string[];         // 사용자가 입력한 성향/강점
  derived: string[];          // CV에서 파생한 신호
  calibration: string;        // 답변 톤 보정 지침(예: 겸양→성과 명시적 소유)
}

export interface SessionContext {
  jobDescription: string;
  company: string;
  persona: PersonaProfile;
  corpus: ExperienceChunk[];  // 이 후보의 전체 경험 조각
}

// M4 STT 스트림 이벤트
export type TranscriptEvent =
  | { type: "partial"; text: string; tStartMs: number; tEndMs: number }
  | { type: "final";   text: string; tStartMs: number; tEndMs: number };

// M4 STT 결과
export interface STTResult {
  text: string;
  isFinal: boolean;
  confidence: number;
  tMs: number;
}

// M5 트리거 이벤트
export interface QuestionComplete { text: string; confidence: number; tMs: number }

// M7 스트리밍 출력
export interface AnswerDelta {
  intent?: string;    // 첫 델타에 1회 (한국어 속뜻)
  grounded?: boolean; // 근거 여부
  delta: string;      // 영어 답변 토큰 조각
  done: boolean;
}
