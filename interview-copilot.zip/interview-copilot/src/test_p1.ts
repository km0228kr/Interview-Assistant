import { analyzeProfile } from './m1_preanalysis.js';
import { KnowledgeStore } from './m2_store.js';
import { generateAnswer } from './m7_generation.js';
import type { SessionContext } from './types.js';
import * as fs from 'fs';

async function main() {
  console.log('--- P1 Milestone Test: Brain Validation ---');
  
  // 1. Mock CV (since we don't have a real one uploaded yet, we'll create a dummy text file)
  const dummyCvPath = './dummy_cv.txt';
  fs.writeFileSync(dummyCvPath, `
권경민 (Kwon Kyung-min)
경력 사항:
- TechCorp 소프트웨어 엔지니어 (2020-2023)
- 모놀리식 아키텍처를 Node.js와 AWS를 사용하여 마이크로서비스로 전환하는 프로젝트 리드.
- 대기 시간을 40% 감소시키고 100만 명 이상의 사용자를 위한 확장성 개선.
- WebSocket과 Redis를 이용한 실시간 알림 시스템 구축.
기술 스택: TypeScript, Node.js, AWS, Redis, 시스템 디자인.
  `);

  console.log('1. Analyzing Profile (M1)...');
  const { corpus, persona } = await analyzeProfile({ files: [dummyCvPath] });
  console.log(`Extracted ${corpus.length} experience chunks.`);
  
  // 2. Store in Knowledge Store (M2)
  console.log('2. Storing in Knowledge Store (M2)...');
  const store = new KnowledgeStore();
  await store.upsertCorpus(corpus);

  // 3. Generate Answer (M7)
  console.log('3. Generating Answer (M7) for question: "Tell me about a challenging technical project you led."');
  const ctx: SessionContext = {
    jobDescription: 'Senior Backend Engineer role focused on scalable systems.',
    company: 'GlobalTech',
    persona,
    corpus: store.getAll(),
  };

  const question = {
    text: 'Tell me about a challenging technical project you led.',
    confidence: 1.0,
    tMs: Date.now(),
  };

  process.stdout.write('Answer: ');
  let fullAnswer = '';
  try {
    for await (const delta of generateAnswer(question, ctx)) {
      if (delta.delta) {
        fullAnswer += delta.delta;
        process.stdout.write(delta.delta);
      }
      if (delta.done) break;
    }
  } catch (err) {
    console.error('\nError during answer generation:', err);
  }
  
  console.log('\n\n--- Full Answer ---\n' + fullAnswer + '\n------------------');
  console.log('\n--- Test Complete ---');
}

main().catch(console.error);
