import { OpenAI } from 'openai';
import dotenv from 'dotenv';
dotenv.config();

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
  baseURL: process.env.OPENAI_API_BASE,
});

async function main() {
  console.log('Testing OpenAI API...');
  console.log('Base URL:', process.env.OPENAI_API_BASE);
  try {
    const response = await openai.chat.completions.create({
      model: 'gpt-4o-mini',
      messages: [{ role: 'user', content: 'Say hello' }],
    });
    console.log('Response:', JSON.stringify(response, null, 2));
  } catch (err) {
    console.error('Error:', err);
  }
}

main();
