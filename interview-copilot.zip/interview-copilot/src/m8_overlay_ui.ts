/**
 * M8: Overlay UI
 * 
 * In a real Electron/Tauri app, this would render an overlay on top of the interview screen.
 * For now, we provide a simple HTML/CSS structure and event handlers.
 */

export interface OverlayState {
  transcript: string;
  answer: string;
  status: 'listening' | 'thinking' | 'speaking' | 'error';
  confidence: number;
}

export class OverlayUI {
  private state: OverlayState = {
    transcript: '',
    answer: '',
    status: 'listening',
    confidence: 0
  };

  public getHTML(): string {
    return `
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Interview Copilot Overlay</title>
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body {
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      background: transparent;
      color: #fff;
    }
    
    .overlay-container {
      position: fixed;
      bottom: 20px;
      right: 20px;
      width: 400px;
      max-height: 500px;
      background: rgba(20, 20, 30, 0.95);
      border: 1px solid rgba(100, 200, 255, 0.3);
      border-radius: 12px;
      padding: 16px;
      box-shadow: 0 8px 32px rgba(0, 0, 0, 0.3);
      backdrop-filter: blur(10px);
      overflow-y: auto;
      z-index: 10000;
    }

    .status-badge {
      display: inline-block;
      padding: 4px 12px;
      border-radius: 20px;
      font-size: 12px;
      font-weight: 600;
      margin-bottom: 12px;
      text-transform: uppercase;
    }

    .status-badge.listening {
      background: rgba(100, 200, 100, 0.3);
      color: #90EE90;
    }

    .status-badge.thinking {
      background: rgba(255, 165, 0, 0.3);
      color: #FFD700;
      animation: pulse 1s infinite;
    }

    .status-badge.speaking {
      background: rgba(100, 150, 255, 0.3);
      color: #87CEEB;
      animation: pulse 1s infinite;
    }

    .status-badge.error {
      background: rgba(255, 100, 100, 0.3);
      color: #FF6B6B;
    }

    @keyframes pulse {
      0%, 100% { opacity: 1; }
      50% { opacity: 0.6; }
    }

    .section {
      margin-bottom: 16px;
    }

    .section-label {
      font-size: 11px;
      text-transform: uppercase;
      color: rgba(255, 255, 255, 0.5);
      margin-bottom: 6px;
      letter-spacing: 0.5px;
    }

    .transcript-box {
      background: rgba(0, 0, 0, 0.3);
      border-left: 2px solid rgba(100, 200, 255, 0.5);
      padding: 10px;
      border-radius: 4px;
      font-size: 13px;
      line-height: 1.5;
      min-height: 40px;
      max-height: 100px;
      overflow-y: auto;
      color: rgba(255, 255, 255, 0.8);
    }

    .answer-box {
      background: rgba(0, 0, 0, 0.3);
      border-left: 2px solid rgba(100, 255, 150, 0.5);
      padding: 10px;
      border-radius: 4px;
      font-size: 13px;
      line-height: 1.6;
      min-height: 60px;
      max-height: 200px;
      overflow-y: auto;
      color: rgba(255, 255, 255, 0.9);
    }

    .confidence-bar {
      height: 4px;
      background: rgba(255, 255, 255, 0.1);
      border-radius: 2px;
      overflow: hidden;
      margin-top: 8px;
    }

    .confidence-fill {
      height: 100%;
      background: linear-gradient(90deg, #4CAF50, #8BC34A);
      transition: width 0.3s ease;
    }

    .empty-state {
      color: rgba(255, 255, 255, 0.4);
      font-size: 12px;
      font-style: italic;
    }
  </style>
</head>
<body>
  <div class="overlay-container">
    <div class="status-badge listening" id="status">Listening</div>

    <div class="section">
      <div class="section-label">Interviewer Question</div>
      <div class="transcript-box" id="transcript">
        <span class="empty-state">Waiting for question...</span>
      </div>
    </div>

    <div class="section">
      <div class="section-label">Your Answer</div>
      <div class="answer-box" id="answer">
        <span class="empty-state">Answer will appear here...</span>
      </div>
      <div class="confidence-bar">
        <div class="confidence-fill" id="confidence" style="width: 0%"></div>
      </div>
    </div>
  </div>

  <script>
    // This will be connected to the backend orchestrator
    window.updateOverlay = function(state) {
      const statusEl = document.getElementById('status');
      const transcriptEl = document.getElementById('transcript');
      const answerEl = document.getElementById('answer');
      const confidenceEl = document.getElementById('confidence');

      // Update status badge
      statusEl.className = 'status-badge ' + state.status;
      statusEl.textContent = state.status.charAt(0).toUpperCase() + state.status.slice(1);

      // Update transcript
      if (state.transcript) {
        transcriptEl.textContent = state.transcript;
      }

      // Update answer
      if (state.answer) {
        answerEl.textContent = state.answer;
      }

      // Update confidence
      confidenceEl.style.width = (state.confidence * 100) + '%';
    };
  </script>
</body>
</html>
    `;
  }

  public setState(state: Partial<OverlayState>) {
    this.state = { ...this.state, ...state };
  }

  public getState(): OverlayState {
    return this.state;
  }
}
