import { OpenAI } from 'openai';
import { config } from './config.js';

const openai = new OpenAI({
  apiKey: config.LLM_KEY,
  baseURL: config.LLM_BASE_URL,
});

async function main() {
  console.log('Testing LLM Stream with model:', config.LLM_MODEL);
  try {
    const stream = await openai.chat.completions.create({
      model: config.LLM_MODEL,
      messages: [{ role: 'user', content: 'Say hello world' }],
      stream: true,
    });

    for await (const chunk of stream) {
      const content = chunk.choices[0]?.delta?.content || '';
      process.stdout.write(content);
    }
    console.log('\nStream complete.');
  } catch (error) {
    console.error('Stream error:', error);
  }
}

main();
