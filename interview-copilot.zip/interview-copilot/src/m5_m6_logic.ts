import { STTResult, QuestionComplete } from './types.js';

/**
 * M5: Turn Detection
 * Logic to decide if the interviewer has finished their question.
 */
export class TurnDetector {
  private lastText: string = '';
  private lastTime: number = 0;
  private silenceThreshold: number = 1500; // ms

  public process(stt: STTResult): QuestionComplete | null {
    // Basic heuristic: if it's a final transcript, we consider it a potential turn end.
    // In a real app, we'd use VAD (Voice Activity Detection) + LLM-based semantic check.
    if (stt.isFinal && stt.text.trim().length > 10) {
      return {
        text: stt.text,
        confidence: stt.confidence,
        tMs: stt.tMs
      };
    }
    return null;
  }
}

/**
 * M6: Translation Track (Real-time subtitle support)
 */
export class TranslationTrack {
  public async translate(text: string): Promise<string> {
    // Real app: Call Google Translate or DeepL API
    // Sandbox: Just return a placeholder or use LLM if needed
    return `[Translation of: ${text}]`;
  }
}
