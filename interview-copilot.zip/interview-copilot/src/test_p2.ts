import { InterviewOrchestrator, UIHandler } from './m9_orchestrator.js';
import { analyzeProfile } from './m1_preanalysis.js';
import * as fs from 'fs';
import path from 'path';

async function main() {
  console.log('--- P2 Milestone Test: Full Flow Validation ---');

  // 1. Prepare Profile
  const dummyCV = path.join(process.cwd(), 'dummy_cv.txt');
  fs.writeFileSync(dummyCV, `
Kwon Kyung-min
- Software Engineer at TechCorp (2020-2023)
- Led monolith to microservices migration using Node.js and AWS.
- Reduced latency by 40% and improved scalability for 1M+ users.
- Built real-time notification system using WebSocket and Redis.
  `);

  console.log('1. Analyzing Profile...');
  const { corpus, persona } = await analyzeProfile({ files: [dummyCV] });
  
  const ctx = {
    jobDescription: "Senior Backend Engineer role focused on scalable systems.",
    company: "GlobalTech",
    persona,
    corpus
  };

  // 2. Setup Orchestrator
  const ui: UIHandler = {
    onTranscript: (text, isFinal) => {
      process.stdout.write(`\r[STT] ${text}${isFinal ? '\n' : ''}`);
    },
    onAnswerDelta: (delta) => {
      if (delta.delta) {
        process.stdout.write(delta.delta);
      }
      if (delta.done) {
        console.log('\n--- Answer Complete ---');
      }
    },
    onStatusChange: (status) => {
      console.log(`\n[STATUS] ${status}`);
    }
  };

  const orchestrator = new InterviewOrchestrator(ctx, ui);
  await orchestrator.start();

  // 3. Simulate Interview Question
  console.log('\n2. Simulating Interviewer Question...');
  orchestrator.mockInterviewer("Could you explain how you handled the microservices migration at TechCorp?");

  // Wait for answer
  await new Promise(resolve => setTimeout(resolve, 15000));
  orchestrator.stop();
  console.log('\n--- P2 Test Complete ---');
}

main().catch(console.error);
