import { DeepgramSTT } from './m4_stt.js';
import { TurnDetector } from './m5_m6_logic.js';
import { generateAnswer } from './m7_generation.js';
import { SessionContext, STTResult, AnswerDelta } from './types.js';

export interface UIHandler {
  onTranscript: (text: string, isFinal: boolean) => void;
  onAnswerDelta: (delta: AnswerDelta) => void;
  onStatusChange: (status: string) => void;
}

export class InterviewOrchestrator {
  private stt: DeepgramSTT;
  private turnDetector: TurnDetector;
  private ctx: SessionContext;
  private ui: UIHandler;

  constructor(ctx: SessionContext, ui: UIHandler) {
    this.ctx = ctx;
    this.ui = ui;
    this.turnDetector = new TurnDetector();
    
    this.stt = new DeepgramSTT({
      onTranscript: (res) => this.handleTranscript(res),
      onError: (err) => console.error('Orchestrator STT Error:', err)
    });
  }

  public async start() {
    this.ui.onStatusChange('Listening...');
    await this.stt.start();
  }

  public stop() {
    this.stt.stop();
    this.ui.onStatusChange('Stopped');
  }

  private async handleTranscript(res: STTResult) {
    this.ui.onTranscript(res.text, res.isFinal);
    
    const question = this.turnDetector.process(res);
    if (question) {
      this.ui.onStatusChange('Thinking...');
      try {
        for await (const delta of generateAnswer(question, this.ctx)) {
          this.ui.onAnswerDelta(delta);
        }
        this.ui.onStatusChange('Listening...');
      } catch (err) {
        console.error('Generation Error:', err);
        this.ui.onStatusChange('Error in generation');
      }
    }
  }

  // Mock method for testing the flow
  public mockInterviewer(text: string) {
    this.stt.mockTranscript(text, true);
  }
}
