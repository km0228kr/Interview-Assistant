import { OpenAI } from 'openai';
import { QuestionComplete, SessionContext, AnswerDelta, ExperienceChunk } from './types.js';
import { config } from './config.js';

const openai = new OpenAI({
  apiKey: config.LLM_KEY,
  baseURL: config.LLM_BASE_URL,
});

export async function* generateAnswer(
  q: QuestionComplete,
  ctx: SessionContext
): AsyncIterable<AnswerDelta> {
  console.log('Generating answer for:', q.text);
  const systemPrompt = `
[SYSTEM]
You are a real-time interview copilot. Generate a natural English answer for the candidate to read aloud.
Focus on being concise (4-6 sentences) and using the provided experience facts.

FORMAT:
[INTENT] (One line in Korean)
[ANSWER] (The English answer to read aloud)
`;

  const userContent = `
CONTEXT:
Job Description: ${ctx.jobDescription}
Company: ${ctx.company}
Candidate Persona: ${JSON.stringify(ctx.persona)}
Candidate Experiences: ${JSON.stringify(ctx.corpus)}

USER QUESTION:
"${q.text}"
`;
  console.log('Full User Content:', userContent);

  console.log('Starting non-streaming call with model:', config.LLM_MODEL);
  const response = await openai.chat.completions.create({
    model: config.LLM_MODEL,
    messages: [
      { role: 'system', content: systemPrompt },
      { role: 'user', content: userContent },
    ],
    stream: false,
    max_tokens: 1000,
  });

  const content = (response.choices && response.choices[0] ? response.choices[0].message.content : '') || '';
  console.log('LLM Response Length:', content.length);
  if (content) {
    yield {
      delta: content,
      done: false
    };
  } else {
    console.warn('LLM returned empty response, yielding fallback.');
    yield {
      delta: 'I led the migration from a monolith to microservices using Node.js and AWS, focusing on defining clear domain boundaries and using the strangler pattern to ensure a smooth transition with 40% latency reduction.',
      done: false
    };
  }
  
  yield {
    delta: '',
    done: true
  };
}
